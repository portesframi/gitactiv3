/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package shooping;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ingrid
 */
public class ShoopingCartIT {
    
    public ShoopingCartIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getBalance method, of class ShoopingCart.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        ShoopingCart instance = new ShoopingCart();
        double expResult = 0.0;
        double result = instance.getBalance();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addItem method, of class ShoopingCart.
     */
    @Test
    public void testAddItem() {
        System.out.println("addItem");
        Product item = null;
        ShoopingCart instance = new ShoopingCart();
        instance.addItem(item);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of removeItem method, of class ShoopingCart.
     */
    @Test
    public void testRemoveItem() {
        System.out.println("removeItem");
        Product item = null;
        ShoopingCart instance = new ShoopingCart();
        instance.removeItem(item);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getItemCount method, of class ShoopingCart.
     */
    @Test
    public void testGetItemCount() {
        System.out.println("getItemCount");
        ShoopingCart instance = new ShoopingCart();
        int expResult = 0;
        int result = instance.getItemCount();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of empty method, of class ShoopingCart.
     */
    @Test
    public void testEmpty() {
        System.out.println("empty");
        ShoopingCart instance = new ShoopingCart();
        instance.empty();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
