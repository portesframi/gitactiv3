/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shooping;

/**
 *
 * @author frami
 */

import java.util.*;

public class ShoopingCart {

    private ArrayList items;

    public ShoopingCart() {
        items = new ArrayList();
    }

    public double getBalance() {
        double balance = 0.00;
        for (Iterator i = items.iterator(); i.hasNext();) {
            Product item = (Product) i.next();
            balance += item.getPrice();
        }
 
        return balance;
    }

    public void addItem(Product item) {
        items.add(item);
    }

    public void removeItem(Product item) {
        items.remove(item);
    }

    public int getItemCount() {
        return items.size();
    }

    public void empty() {
        items.clear();
    }
}
